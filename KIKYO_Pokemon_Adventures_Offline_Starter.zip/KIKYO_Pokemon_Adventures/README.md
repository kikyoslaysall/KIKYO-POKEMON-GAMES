# KIKYO: Pokémon Adventures — offline starter project

This is an early playable offline prototype, not the complete game yet. It includes a mobile game-style interface, starter selection, a small encounter/battle/catch loop, team, Pokédex, regions, trainer profile, and local save storage.

## Build an APK using GitHub Actions (phone-friendly)

1. Create a new **public or private** GitHub repository.
2. Upload the contents of this folder to the repository (upload files, not the outer folder).
3. Open the repository's **Actions** tab.
4. If GitHub asks, enable Actions.
5. Choose **Build KIKYO Android APK** and tap **Run workflow** (or push a commit to `main`).
6. When the run finishes, open it and download the `kikyo-offline-debug-apk` artifact.
7. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from your browser/file manager.

## Local development

Requires Node.js 20+ and Android Studio / Android SDK for local Android builds.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
```

Then build the debug APK from the generated `android` directory with Gradle.

## Important

- The game currently saves on this device using browser local storage. Clearing app data or uninstalling may erase progress.
- This prototype is offline after installation; Google Fonts are optional and may not load without internet. System fonts will be used as fallback.
- The battle mechanics and Pokémon list are starter scaffolding and need expansion/testing before calling this a complete game.
- This is an unofficial fan-made project and is not affiliated with or endorsed by Nintendo, Game Freak, or The Pokémon Company. Use artwork and other assets only when you have permission to use them.
