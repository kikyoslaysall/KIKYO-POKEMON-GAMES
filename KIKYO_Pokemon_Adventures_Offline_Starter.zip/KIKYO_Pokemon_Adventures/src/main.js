import './style.css';

const starters = [
  { id:'bulbasaur', name:'Bulbasaur', type:'GRASS / POISON', emoji:'🌱', color:'#4c9b70', hp:45, attack:9, level:5, xp:0 },
  { id:'charmander', name:'Charmander', type:'FIRE', emoji:'🔥', color:'#e58b4c', hp:39, attack:11, level:5, xp:0 },
  { id:'squirtle', name:'Squirtle', type:'WATER', emoji:'💧', color:'#559bd2', hp:44, attack:10, level:5, xp:0 }
];
const defaultSave = () => ({
  trainer: { name:'Trainer', level:1, xp:0, coins:300, badges:0 },
  region:'Kanto', selectedStarter:null, party:[], dex:[], potions:3, pokeballs:5,
  wins:0, seen:[], lastSaved:Date.now()
});
let save = loadSave();
let currentTab = 'home';
let wild = null;
let battleLog = 'A wild Pokémon appeared!';
let busy = false;

function loadSave(){
  try { return { ...defaultSave(), ...JSON.parse(localStorage.getItem('kikyo-save') || '{}') }; }
  catch { return defaultSave(); }
}
function persist(){
  save.lastSaved = Date.now();
  localStorage.setItem('kikyo-save', JSON.stringify(save));
  const el = document.querySelector('#save-state');
  if(el) el.textContent = 'SAVED';
}
function esc(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function cardMon(mon, index=0){
  const colors = {Bulbasaur:'#4c9b70',Charmander:'#e58b4c',Squirtle:'#559bd2',Pikachu:'#e4bd43',Pidgey:'#a68b68',Rattata:'#9875ad',Caterpie:'#7cae57',Oddish:'#548d77'};
  const color = colors[mon.name] || '#6d7d91';
  return `<article class="mon-card" style="--mon:${color}">
    <div class="mon-art">${mon.emoji || '✨'}</div>
    <div class="mon-info"><b>${esc(mon.name)}</b><span>${esc(mon.type || 'NORMAL')}</span>
    <small>Lv. ${mon.level} · HP ${mon.hp}/${mon.maxHp || mon.hp}</small></div>
  </article>`;
}
function shell(){
 document.querySelector('#app').innerHTML = `
 <div class="game-shell">
  <header class="topbar">
   <div class="brand"><div class="brand-mark">K</div><div><b>KIKYO</b><small>POKÉMON ADVENTURES</small></div></div>
   <div class="save-pill"><i></i><span id="save-state">OFFLINE</span></div>
  </header>
  <main id="screen"></main>
  <nav class="bottom-nav">
   ${[['home','⌂','Home'],['explore','⌖','Explore'],['team','◈','Team'],['pokedex','▦','Pokédex'],['profile','◎','Profile']].map(([id,icon,label])=>`<button data-tab="${id}" class="${currentTab===id?'active':''}"><span>${icon}</span><small>${label}</small></button>`).join('')}
  </nav>
 </div>`;
 document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{currentTab=b.dataset.tab; render();}));
 render();
}
function render(){
 const screen=document.querySelector('#screen');
 if(!screen) return;
 if(!save.selectedStarter){ renderStarter(screen); return; }
 const views={home:homeView,explore:exploreView,team:teamView,pokedex:dexView,profile:profileView};
 screen.innerHTML=(views[currentTab]||homeView)();
 bindActions();
 document.querySelectorAll('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===currentTab));
}
function renderStarter(screen){
 screen.innerHTML=`<section class="welcome">
  <div class="hero-orb">⚡</div><p class="eyebrow">A NEW JOURNEY BEGINS</p>
  <h1>Choose your<br><em>first partner.</em></h1>
  <p class="muted">Every great adventure starts with one Pokémon. Choose carefully, Trainer.</p>
  <label class="field-label" for="trainer-name">TRAINER NAME</label>
  <input id="trainer-name" maxlength="16" placeholder="Enter your name" value="${esc(save.trainer.name==='Trainer'?'':save.trainer.name)}">
  <div class="starter-grid">${starters.map((m,i)=>`<button class="starter-choice" data-starter="${i}" style="--mon:${m.color}"><span>${m.emoji}</span><b>${m.name}</b><small>${m.type}</small></button>`).join('')}</div>
  <p class="tiny">Your progress is saved on this device.</p>
 </section>`;
 document.querySelectorAll('[data-starter]').forEach(b=>b.addEventListener('click',()=>{
  const m={...starters[Number(b.dataset.starter)]};
  const name=document.querySelector('#trainer-name').value.trim();
  save.trainer.name=name||'Trainer'; save.selectedStarter=m.id;
  save.party=[{...m,maxHp:m.hp}]; save.dex=[m.id]; save.seen=[m.id];
  persist(); currentTab='home'; render();
 }));
}
function homeView(){
 const lead=save.party[0];
 return `<section class="home-hero">
  <div class="hero-copy"><p class="eyebrow">WELCOME BACK, ${esc(save.trainer.name.toUpperCase())}</p><h1>Your adventure<br><em>continues.</em></h1>
  <p class="muted">The ${esc(save.region)} region is waiting for you.</p>
  <button class="primary-btn" data-go="explore">EXPLORE REGION <span>→</span></button></div>
  <div class="hero-creature">${lead?.emoji||'⚡'}</div>
 </section>
 <div class="stat-row"><div><small>TRAINER LV.</small><b>${save.trainer.level}</b></div><div><small>POKÉMON</small><b>${save.party.length}/6</b></div><div><small>BADGES</small><b>${save.trainer.badges}</b></div></div>
 <section class="section"><div class="section-head"><div><p class="eyebrow">YOUR PARTNER</p><h2>Active team</h2></div><button class="text-btn" data-go="team">VIEW ALL →</button></div>
 <div class="mon-list">${save.party.slice(0,2).map(cardMon).join('')||'<p class="muted">Your team is waiting.</p>'}</div></section>
 <section class="quick-actions"><button data-go="explore"><span>🌿</span><b>Wild encounters</b><small>Find Pokémon</small></button><button data-go="pokedex"><span>📖</span><b>Pokédex</b><small>${save.dex.length} registered</small></button></section>`;
}
const wildPool=[
 {id:'pidgey',name:'Pidgey',type:'NORMAL / FLYING',emoji:'🐦',hp:32,attack:7,level:3},
 {id:'rattata',name:'Rattata',type:'NORMAL',emoji:'🐭',hp:30,attack:8,level:3},
 {id:'caterpie',name:'Caterpie',type:'BUG',emoji:'🐛',hp:28,attack:6,level:2},
 {id:'oddish',name:'Oddish',type:'GRASS / POISON',emoji:'🌿',hp:35,attack:7,level:4},
 {id:'pikachu',name:'Pikachu',type:'ELECTRIC',emoji:'⚡',hp:34,attack:10,level:4}
];
function exploreView(){
 return `<section class="page-heading"><p class="eyebrow">${esc(save.region.toUpperCase())} REGION</p><h1>Wild <em>frontier</em></h1><p class="muted">Explore the tall grass and see who you meet.</p></section>
 <div class="route-card"><div class="route-sun">☀️</div><div><small>AVAILABLE AREA</small><h2>Route 1 · Green Path</h2><p>Quiet trails, rustling grass and new friends.</p></div></div>
 <div class="resource-row"><span>🔴 Poké Balls <b>${save.pokeballs}</b></span><span>🧪 Potions <b>${save.potions}</b></span></div>
 <button class="primary-btn full" data-action="encounter">SEARCH THE GRASS <span>→</span></button>
 ${wild?battleView():''}
 <section class="section"><div class="section-head"><div><p class="eyebrow">REGION SELECT</p><h2>Choose destination</h2></div></div><div class="region-grid">${['Kanto','Johto','Hoenn','Sinnoh'].map(r=>`<button data-region="${r}" class="${save.region===r?'chosen':''}">${r}<small>${r===save.region?'CURRENT':'UNLOCKED'}</small></button>`).join('')}</div></section>`;
}
function battleView(){
 return `<div class="battle-panel"><div class="battle-top"><span>WILD ENCOUNTER</span><span>Lv. ${wild.level}</span></div>
 <div class="battle-creatures"><div><div class="battle-emoji">${wild.emoji}</div><b>${wild.name}</b><small>${wild.type}</small><div class="hp-track"><i style="width:${Math.max(0,wild.hp/wild.maxHp*100)}%"></i></div></div><div class="vs">VS</div><div><div class="battle-emoji">${save.party[0].emoji}</div><b>${save.party[0].name}</b><small>YOUR PARTNER</small><div class="hp-track"><i style="width:100%"></i></div></div></div>
 <p class="battle-log">${esc(battleLog)}</p><div class="battle-actions"><button data-action="attack" ${busy?'disabled':''}>⚔️ ATTACK</button><button data-action="catch" ${save.pokeballs<1?'disabled':''}>🔴 CATCH</button><button data-action="run">RUN</button></div></div>`;
}
function teamView(){return `<section class="page-heading"><p class="eyebrow">YOUR COMPANIONS</p><h1>Pokémon <em>team</em></h1><p class="muted">Your party can hold up to six Pokémon.</p></section><div class="mon-list">${save.party.map(cardMon).join('')||'<p>No Pokémon yet.</p>'}</div><div class="info-box">Your Pokémon and their progress are stored locally on this device.</div>`;}
function dexView(){return `<section class="page-heading"><p class="eyebrow">FIELD GUIDE</p><h1>Poké<em>dex</em></h1><p class="muted">${save.dex.length} Pokémon registered so far.</p></section><div class="dex-grid">${[...starters,...wildPool].map(m=>{const got=save.dex.includes(m.id);return `<div class="dex-item ${got?'':'unknown'}"><span>${got?m.emoji:'?'}</span><b>${got?m.name:'Unknown'}</b><small>${got?m.type:'Not discovered'}</small></div>`}).join('')}</div>`;}
function profileView(){return `<section class="profile-card"><div class="avatar">🧢</div><p class="eyebrow">POKÉMON TRAINER</p><h1>${esc(save.trainer.name)}</h1><div class="level-badge">LEVEL ${save.trainer.level}</div><div class="xp-track"><i style="width:${save.trainer.xp}%"></i></div><small>${save.trainer.xp}/100 XP TO NEXT LEVEL</small></section><div class="stat-row"><div><small>COINS</small><b>🪙 ${save.trainer.coins}</b></div><div><small>WINS</small><b>${save.wins}</b></div><div><small>BADGES</small><b>${save.trainer.badges}</b></div></div><button class="secondary-btn full" data-action="rename">EDIT TRAINER NAME</button><button class="danger-btn full" data-action="reset">RESET LOCAL SAVE</button><p class="tiny center">Offline demo build · Save data stays on this device.</p>`;}
function bindActions(){
 document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{currentTab=b.dataset.go;render();});
 document.querySelectorAll('[data-region]').forEach(b=>b.onclick=()=>{save.region=b.dataset.region;persist();render();});
 document.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>action(b.dataset.action));
}
function action(a){
 if(a==='encounter'){wild={...wildPool[Math.floor(Math.random()*wildPool.length)]};wild.maxHp=wild.hp;wild.hp=wild.maxHp;save.seen=[...new Set([...save.seen,wild.id])];battleLog=`A wild ${wild.name} appeared!`;render();return;}
 if(!wild)return;
 if(a==='attack'){
  const p=save.party[0]; wild.hp-=p.attack;
  if(wild.hp<=0){battleLog=`You won! ${wild.name} ran off. You earned 20 XP.`;save.wins++;save.trainer.xp+=20;save.trainer.coins+=15;if(save.trainer.xp>=100){save.trainer.level++;save.trainer.xp-=100;}wild=null;persist();render();return;}
  battleLog=`${p.name} attacked! The wild ${wild.name} is weakened.`; wild.hp-=Math.max(1,Math.floor(wild.attack/2));
  if(wild.hp<=0){battleLog=`You won! You earned 20 XP.`;save.wins++;save.trainer.xp+=20;save.trainer.coins+=15;wild=null;persist();}
  render();return;
 }
 if(a==='catch'){
  if(save.pokeballs<=0)return;save.pokeballs--;
  if(Math.random()<0.62 && save.party.length<6){const caught={...wild,maxHp:wild.maxHp};save.party.push(caught);save.dex=[...new Set([...save.dex,wild.id])];battleLog=`${wild.name} joined your team!`;wild=null;}
  else battleLog=`Oh no! It escaped the Poké Ball. Try again.`;
  persist();render();return;
 }
 if(a==='run'){wild=null;render();return;}
}
function rename(){const n=prompt('Enter your trainer name',save.trainer.name);if(n&&n.trim()){save.trainer.name=n.trim().slice(0,16);persist();render();}}
document.addEventListener('click',e=>{const b=e.target.closest('[data-action="rename"]');if(b)rename();});
document.addEventListener('click',e=>{const b=e.target.closest('[data-action="reset"]');if(b&&confirm('Reset all KIKYO game progress on this device?')){localStorage.removeItem('kikyo-save');save=defaultSave();wild=null;render();}});
shell();
